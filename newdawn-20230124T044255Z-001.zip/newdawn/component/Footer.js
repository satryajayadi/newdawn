const Footer = () => {
  return (
    <>
      <div>
        <p>Limbad</p>
      </div>
    </>
  );
};

export default Footer;
