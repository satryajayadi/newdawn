function handleClick() {
  alert(`Belum Ada Sabar Ya:)`);
}

export default handleClick;

export function Collection() {
  alert(`Ada di Bio:)`);
}
